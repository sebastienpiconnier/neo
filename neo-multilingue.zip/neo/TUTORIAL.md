# Getting Started with NEO

**Installing**

Mac: open the .dmg for older Intel macs ... or the arm64.dmg for Apple silicon machines. Drag NEO into Applications. 
PC: run the installer or the standalone .exe.

NEO will ask you two things when it opens: your name (this goes on your title pages, and you can leave it blank and be Anonymous), and whether you're a **pantser or a plotter**. If you don't know the difference, pantsers write by the seat of their pants and figure our the story as they go. Plotters outline first. There's no wrong answer, and you can change it later. The difference in NEO is plotters have new books that open in the Outline tab, while pantsers get a blank page. Then NEO asks you to pick a font and a drop cap style and shows you exactly what your page will look like. You can change these options later.

**Your bookshelf**

NEO opens on a bookshelf because you're a novelist, and novelists write books. (Or short stories; I won't judge). Click the dashed rectangle with the + in it and you've started your first story. That's it. And guess what? It already looks like a book!

You can add more shelves (button in the top right corner), rename any shelf by clicking its label, and drag books around like you're rearranging a real bookshelf. Right-click a book to set a word count goal (this puts a subtle progress bar on the cover. You have to write to see it!). You can also right-click to remove a book. Each book gets its own colored cover; hover over one and click the little ↻ refresh button if you want a new one. Or drag 2:3 ratio cover art right on the book to make it extra purty.

**Author(s)**

New in v0.4.2 is the ability to have bookshelves for each of your pen names. Just click the author name you already have, and here you can rename that author or "Add a Pen Name..." Click that and create a new set of shelves under a different name. Title pages are adorned appropriately, and with two clicks you can switch to a different author. If you delete an author, their shelves will move to another author's shelves, to create a safety valve (all books are kept in the same Library folder anyway).

**Writing**

Here's everything you need to know about writing in NEO:

Type your title. Hit Enter. Start writing.

The first paragraph of every chapter gets a big drop cap, like a real book, because **you are writing a real book** and NEO wants you to feel that every time you open it up. The writing should delight you the way it delights your readers!

When you finish a scene and want a section break — those little *** dividers — hit **Enter twice**. When you finish a chapter, hit **Enter three times**. A new chapter appears, numbered. If this is the first time you've created a new chapter, it will be Chapter 2 and NEO will label your first section Chapter 1 (this way short stories are exported without chapters at all). If you later squeeze a chapter in between two others, every chapter renumbers itself.

Type two hyphens and get an em dash — like that. The change happens immediately. Type three periods and get a real ellipsis… Quotes curl themselves in the right direction (imported files might have weird quotes; working on this).

Note: **there is no spellcheck while you write.** No red squiggles yelling WRONG at you while you're mid-thought about a made-up city with a made-up name. Your creative brain doesn't need a klaxon. When you're ready to check spelling, hit ⌘; and it'll turn on. Right-click the squiggles for suggestions. Hit ⌘; again to get back into the flow.

**Poetry Paragraph**

A new feature added in v0.8.0: the "Poetry Paragraph." If you SHIFT + ENTER, you'll get an indented paragraph style, default italicized (but you can change it with CTRL + I). It lets you put quotes, poetry, alien chatter, spells being cast, etc. in your manuscript. You can even put a Poetry Paragraph BEFORE the start of a chapter. Just hit SHIFT + ENTER from the chapter title. Or toggle any paragraph to a Poetry Paragraph in the Format menu.

**When you need to mark a spot and keep moving**

I used to type XXX in drafts when I needed to change something later (or look something up, or verify some continuity). Now, you can just hit ⌘⇧X instead. NEO drops a little mark, makes a sticky note in the margin for later, and you keep writing. The chapter list shows a red dot everywhere you left a sticky. The notes are on the hidden right panel any time you need to look for something to fix.

**Darlings**

Kill your darlings, they say. Well, it never gets easy. You're a writer, and we all secretly believe the last good sentence we wrote is the last good sentence we'll ever write.

Instead of deleting it, select it and drag it down onto the **Darlings** tab at the bottom of the screen. It leaves your manuscript, but it's saved forever. If you change your mind, you can restore what you deleted to the exact spot it came from. Kill without remorse. You can now resurrect your beloveds.

**The hidden panels**

The screen stays distraction-free until you need something. Roll your mouse to the **left edge** and the chapter list slides out — every chapter, its word count, a note field where you can jot what happens in it. You can outline an entire novel from this panel if you want. Push to the **right edge** for your notes and comments. The little ☉ here pins it open if you're doing a revision pass.

Along the bottom: tabs for your Notes, your Outline, and your Darlings. Plus a word count. Click the word count to toggle between the whole book and just this chapter.

The UI is deliberately difficult to see unless you roll your mouse over the semi-hidden options. If you prefer to brighten things up, there's an option for you under the VIEW menu.

**Goals, sprints, and the chart**

Click the word counter that says "0 today" and you get the progress room: set a daily goal, set a book goal, start a word sprint, and watch a chart of your last thirty days that looks a lot like the NaNoWriMo graph, because that graph is what got me through many of my novels. Get addicted to writing, to the daily habit!

**Cover Art**

New books are automatically given cover art with a seeded abstract look (six art styles, six type templates, typefaces bundled with NEO) so no two stories on the shelf look alike. Once a story passes 1,000 words, NEO can read it and paint a cover from the text. This is a bit more work but totally worth it. Get an OpenAI API key from their website and paste it into **File → Cover Art…**. The art is generated in the background for about a penny a picture. (These are not meant for publication, just writing inspiration!) The API key is stored encrypted in NEO's own settings, never in your library folder. The title and author are always set in real type on top, so the lettering is never left to a gen-AI model. The ↻ on any book re-rolls its type and colors, or paints it again. And you can always switch back and forth from the seeded modern look to the painted variety.


**Getting your book out**

When your draft is done, the File menu exports to Word for your editor so they can track changes, or PDF, plain text, or Markdown. There's a proper **EPUB** option with a real table of contents built to Amazon's guidelines, but this is not highly tested yet, so use at your own risk!

**Email backup**

Hit ⌘E and NEO emails a timestamped PDF snapshot of your draft to yourself, with a digital fingerprint of the text. Crypto bros rejoice! Not only is this good for having a backup of your work (even though NEO is saving constantly and protecting against crashes), it creates a paper trail proving your words existed on a date, written by you. This feature could be worth $2.4 million dollars someday!

**Safety**

Everything is saved automatically, constantly, into plain ordinary files in a folder called NEO Library in your Documents. Open the folder and look — your chapters are just files. Back them up, sync them with Dropbox, whatever you like. If NEO disappeared tomorrow, every word you wrote would still be there. There's nothing being sent to a cloud (except your own email), nothing anyone else can read, just files on your computer.

**That's it**

That's NEO. Hit ⌘/ anytime to see the shortcut list, but the important bits are: Enter, Enter, Enter. Write, write, write.

Go get it. Your rough draft doesn't have to be good. It just has to exist. If you want to know anything else I've learned about writing and publishing, I've posted it all for free starting here: https://hughhowey.com/writing-insights-part-one-becoming-a-writer/
